

let inputBtn = document.getElementById("input-btn")

// inputBtn.addEventListener("click", function () {
//     console.log("Button clicked!")
// })


let myLead = [""]
let inputEl = document.getElementById("input-el")
console.log(inputBtn)
inputBtn.addEventListener("click", function () {
    myLead.push("www.awesomelead.com")
    myLead.push(inputEl.value)
    console.log(myLead)

    // Clear out the input field
    inputEl.value = ""

    // RENDER FUNCTION
    renderLeads()

    for (let i = 0; i < myLead.length; i++) {
        console.log(myLead[i])
    }
})

// RENDER FUNCTION

function renderLeads() {
    let listItems = " "
    for (let i = 0; i < myLead.length; i++) {
        listItems += "<li>" + myLead[i] + "</li"
        // add a tag
        // listItems += "<li><a target_'blank' href='#'>" + myLead[i] + "</a></li>"
    }
    ulEl.innerHTML = listItems
}

// INNERHTML

let ulEl = document.getElementById("ul-el")
console.log(ulEl)
for (i = 0; i < myLead.length; i++) {
    // // ulEl.textContent += myLead[i] + " "  
    // ulEl.innerHTML += "<li>" + myLead[i] + "</li>"


    // ANOTHER METHOD FOR INNERHTML
    // 1. create element
    // 2.set text content
    // 3.append to ul
    // const li =document.createElement("li")
    // li.textContent = myLead[i]
    // ulEl.append(li)
}





// const container = document.getElementById("container")
// container.innerHTML = "<button onclick='buy()'>Buy!</button>"

// function buy(){
//     container.innerHTML += "<p>Thank you for buying!</p>"
// }


